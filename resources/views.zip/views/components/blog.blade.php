@props(['id' => 'blog'])

<section id="{{ $id }}" class="section blog light-background">
  <div class="container" data-aos="fade-up">

    <div class="section-title">
      <h2>Blog & Updates</h2>
      <p>Stay informed with insights from the intersection of AI, medicine, and global innovation.</p>


    </div>
    <h3 class="section-title">COOMING SOON .. . </h3>

  </div>
</section



ahme shanab what do you doing and 
