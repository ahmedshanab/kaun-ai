<div class="tab-pane fade show" id="extended">
  <div class="row gy-4">
    <div class="col-12 text-center" data-aos="fade-up" data-aos-delay="100">
      <p class="fs-5">
Kaun AI thrives through the energy and dedication of a growing circle of contributors, collaborators, and ambassadors who enrich our mission from diverse perspectives. This extended network includes students, nurses, designers, communicators, analysts, early-career researchers, and professionals from around the world – all united by a shared belief in the transformative power of ethical AI.Their roles may vary, but their impact is essential. Individual profiles and contributions will be showcased here soon.    </div>
  </div>
</div>
