<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Kaun AI</title>
    @vite('resources/css/app.css')
</head>
<body class="bg-gray-50 text-gray-800">

    <!-- Navbar -->
    <x-navbar />

    <!-- Hero Section -->
    <x-hero-section />

    <!-- Footer -->
    <x-footer />

</body>
</html>
